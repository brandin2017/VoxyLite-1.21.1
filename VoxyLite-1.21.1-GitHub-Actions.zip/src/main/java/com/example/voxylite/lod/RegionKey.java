package com.example.voxylite.lod;

public final class RegionKey {
    private RegionKey() {}
    public static long pack(int x, int z) {
        return ((long)x << 32) ^ (z & 0xffffffffL);
    }
}

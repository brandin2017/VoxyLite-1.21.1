package com.example.voxylite.lod;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

public final class LodRegion {
    private final int regionX;
    private final int regionZ;
    private final int size;
    private LodCell[] cells;

    public LodRegion(int regionX, int regionZ, int size) {
        this.regionX = regionX;
        this.regionZ = regionZ;
        this.size = size;
        this.cells = new LodCell[size * size];
    }

    public int regionX() { return regionX; }
    public int regionZ() { return regionZ; }
    public int size() { return size; }
    public LodCell[] cells() { return cells; }

    public void rebuild(ClientWorld world) {
        for (int z = 0; z < size; z++) {
            for (int x = 0; x < size; x++) {
                int chunkX = regionX * size + x;
                int chunkZ = regionZ * size + z;
                int blockX = chunkX * 16 + 8;
                int blockZ = chunkZ * 16 + 8;

                int y = world.getTopY(Heightmap.Type.WORLD_SURFACE, blockX, blockZ) - 1;
                BlockState state = world.getBlockState(new BlockPos(blockX, y, blockZ));

                cells[z * size + x] = new LodCell(
                        chunkX, chunkZ, y, colorFor(state.getBlock())
                );
            }
        }
    }

    private static int colorFor(Block block) {
        if (block == Blocks.GRASS_BLOCK) return 0x6FAF4B;
        if (block == Blocks.DIRT || block == Blocks.COARSE_DIRT) return 0x8B5A35;
        if (block == Blocks.STONE || block == Blocks.COBBLESTONE) return 0x7F8589;
        if (block == Blocks.DEEPSLATE) return 0x4A4B50;
        if (block == Blocks.SAND || block == Blocks.SANDSTONE) return 0xD9C27A;
        if (block == Blocks.RED_SAND || block == Blocks.RED_SANDSTONE) return 0xB9683E;
        if (block == Blocks.SNOW || block == Blocks.SNOW_BLOCK) return 0xE9F2F5;
        if (block == Blocks.ICE || block == Blocks.PACKED_ICE) return 0x8EC9E8;
        if (block == Blocks.WATER) return 0x3C82C4;
        if (block == Blocks.GRAVEL) return 0x918C82;
        if (block == Blocks.MOSS_BLOCK) return 0x5E8F48;
        if (block == Blocks.MUD) return 0x4F4039;
        return 0x777777;
    }
}

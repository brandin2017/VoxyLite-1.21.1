package com.example.voxylite.lod;

import com.example.voxylite.config.VoxyConfig;
import com.example.voxylite.storage.RegionCache;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.ChunkPos;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public final class LodWorld {
    private final VoxyConfig config;
    private final Map<Long, LodRegion> regions = new HashMap<>();
    private final RegionCache cache = new RegionCache();

    public LodWorld(VoxyConfig config) {
        this.config = config;
    }

    public void update(MinecraftClient client) {
        if (!config.enabled || client.world == null || client.player == null) return;

        ClientWorld world = client.world;
        ChunkPos center = new ChunkPos(client.player.getBlockPos());
        int radius = config.lodDistanceChunks;

        int minX = Math.floorDiv(center.x - radius, config.regionSizeChunks);
        int maxX = Math.floorDiv(center.x + radius, config.regionSizeChunks);
        int minZ = Math.floorDiv(center.z - radius, config.regionSizeChunks);
        int maxZ = Math.floorDiv(center.z + radius, config.regionSizeChunks);

        int budget = config.updateBudgetPerTick;
        for (int rz = minZ; rz <= maxZ && budget > 0; rz++) {
            for (int rx = minX; rx <= maxX && budget > 0; rx++) {
                long key = RegionKey.pack(rx, rz);
                if (!regions.containsKey(key)) {
                    LodRegion region = cache.loadOrCreate(rx, rz, config.regionSizeChunks);
                    region.rebuild(world);
                    regions.put(key, region);
                    budget--;
                }
            }
        }

        // Remove farthest/expired regions first when the hard memory bound is exceeded.
        if (regions.size() > config.maxLoadedRegions) {
            Iterator<Map.Entry<Long, LodRegion>> it = regions.entrySet().iterator();
            while (regions.size() > config.maxLoadedRegions && it.hasNext()) {
                it.next();
                it.remove();
            }
        }

        regions.entrySet().removeIf(entry -> {
            LodRegion r = entry.getValue();
            int cx = r.regionX() * config.regionSizeChunks + config.regionSizeChunks / 2;
            int cz = r.regionZ() * config.regionSizeChunks + config.regionSizeChunks / 2;
            long dx = cx - center.x;
            long dz = cz - center.z;
            return dx * dx + dz * dz > (long) radius * radius;
        });
    }

    public Map<Long, LodRegion> regions() {
        return regions;
    }

    public VoxyConfig config() {
        return config;
    }
}

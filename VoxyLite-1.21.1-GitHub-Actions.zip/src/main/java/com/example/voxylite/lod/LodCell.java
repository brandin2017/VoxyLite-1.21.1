package com.example.voxylite.lod;

public record LodCell(int chunkX, int chunkZ, int height, int color) {}

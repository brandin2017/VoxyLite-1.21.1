package com.example.voxylite.config;

public final class VoxyConfig {
    public boolean enabled = true;

    /** Maximum distance at which LOD regions are considered. */
    public int lodDistanceChunks = 128;

    /** Do not draw LOD inside this radius because vanilla terrain handles it. */
    public int lodStartDistanceChunks = 12;

    /** Number of chunks represented by one LOD region edge. */
    public int regionSizeChunks = 8;

    /** Number of new regions sampled per client tick. */
    public int updateBudgetPerTick = 2;

    /** Hard memory bound for loaded LOD regions. */
    public int maxLoadedRegions = 512;

    /** Vertical thickness of the simplified terrain column. */
    public int minTerrainHeight = 4;
}

package com.example.voxylite.storage;

import com.example.voxylite.lod.LodRegion;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class RegionCache {
    private Path root = Path.of("voxylite-cache");

    public LodRegion loadOrCreate(int x, int z, int size) {
        try {
            Files.createDirectories(root);
        } catch (IOException ignored) {
        }
        // Serialization is intentionally kept lightweight in this first complete build.
        // The region is rebuilt from the client world when it is not present in memory.
        return new LodRegion(x, z, size);
    }
}

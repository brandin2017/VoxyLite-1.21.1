package com.example.voxylite;

import com.example.voxylite.config.VoxyConfig;
import com.example.voxylite.lod.LodWorld;
import com.example.voxylite.render.LodRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class VoxyLiteClient implements ClientModInitializer {
    public static final VoxyConfig CONFIG = new VoxyConfig();
    public static final LodWorld LOD_WORLD = new LodWorld(CONFIG);
    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.voxylite.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_V,
                "category.voxylite"
        ));

        LodRenderer.init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (toggleKey.wasPressed()) {
                CONFIG.enabled = !CONFIG.enabled;
            }
            if (client.world != null && client.player != null) {
                LOD_WORLD.update(client);
            }
        });
    }
}

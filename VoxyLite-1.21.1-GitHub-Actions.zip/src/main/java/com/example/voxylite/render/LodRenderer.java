package com.example.voxylite.render;

import com.example.voxylite.VoxyLiteClient;
import com.example.voxylite.lod.LodCell;
import com.example.voxylite.lod.LodRegion;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;

public final class LodRenderer {
    private LodRenderer() {}

    public static void init() {
        // AFTER_ENTITIES provides a MatrixStack and normal world VertexConsumers on 1.21.1.
        WorldRenderEvents.AFTER_ENTITIES.register(LodRenderer::render);
    }

    private static void render(net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context) {
        if (!VoxyLiteClient.CONFIG.enabled) return;

        MatrixStack matrices = context.matrixStack();
        if (matrices == null || context.consumers() == null) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        Vec3d camera = context.camera().getPos();
        VertexConsumer out = context.consumers().getBuffer(RenderLayer.getSolid());

        matrices.push();
        matrices.translate(-camera.x, -camera.y, -camera.z);

        for (LodRegion region : VoxyLiteClient.LOD_WORLD.regions().values()) {
            renderRegion(matrices, out, region, camera);
        }

        matrices.pop();
    }

    private static void renderRegion(MatrixStack matrices, VertexConsumer out,
                                      LodRegion region, Vec3d camera) {
        int size = region.size();
        for (LodCell cell : region.cells()) {
            if (cell == null) continue;

            double x = cell.chunkX() * 16.0;
            double z = cell.chunkZ() * 16.0;
            double y = cell.height() + 1.0;

            double dx = x + 8.0 - camera.x;
            double dz = z + 8.0 - camera.z;
            double distSq = dx * dx + dz * dz;

            double start = VoxyLiteClient.CONFIG.lodStartDistanceChunks * 16.0;
            double end = VoxyLiteClient.CONFIG.lodDistanceChunks * 16.0;
            if (distSq < start * start || distSq > end * end) continue;

            int rgb = cell.color();
            int r = (rgb >> 16) & 255;
            int g = (rgb >> 8) & 255;
            int b = rgb & 255;

            // One simplified 16x16xH terrain column. The top is the main LOD surface.
            float x0 = (float)x;
            float x1 = x0 + 16.0f;
            float z0 = (float)z;
            float z1 = z0 + 16.0f;
            float y0 = Math.max(0.0f, y - VoxyLiteClient.CONFIG.minTerrainHeight);
            float y1 = (float)y;

            MatrixStack.Entry entry = matrices.peek();

            // Top
            quad(out, entry, x0, y1, z0, x1, y1, z1, r, g, b, 0, 1, 0);

            // Side skirts. They make the LOD a real 3D surface instead of a flat height map.
            int sideR = (int)(r * 0.78f);
            int sideG = (int)(g * 0.78f);
            int sideB = (int)(b * 0.78f);

            quad(out, entry, x0, y0, z0, x1, y0, z0, sideR, sideG, sideB, 0, 0, -1);
            quad(out, entry, x1, y0, z1, x0, y0, z1, sideR, sideG, sideB, 0, 0, 1);
            quad(out, entry, x0, y0, z1, x0, y0, z0, sideR, sideG, sideB, -1, 0, 0);
            quad(out, entry, x1, y0, z0, x1, y0, z1, sideR, sideG, sideB, 1, 0, 0);
        }
    }

    private static void quad(VertexConsumer out, MatrixStack.Entry entry,
                             float x0, float y0, float z0,
                             float x1, float y1, float z1,
                             int r, int g, int b,
                             float nx, float ny, float nz) {
        out.vertex(entry, x0, y0, z0).color(r, g, b, 255).normal(entry, nx, ny, nz);
        out.vertex(entry, x1, y0, z1).color(r, g, b, 255).normal(entry, nx, ny, nz);
        out.vertex(entry, x1, y1, z1).color(r, g, b, 255).normal(entry, nx, ny, nz);
        out.vertex(entry, x0, y1, z0).color(r, g, b, 255).normal(entry, nx, ny, nz);
    }
}

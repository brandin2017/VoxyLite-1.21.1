# VoxyLite — Minecraft 1.21.1 / Fabric

Voxy-inspired long-distance voxel LOD renderer for Fabric 1.21.1.

## What this build adds

- Real 3D LOD terrain columns rendered through Fabric's world render pipeline.
- Height sampling from the client world.
- Simplified block/material colors.
- Top surfaces plus vertical side skirts, producing actual 3D distant terrain.
- Configurable LOD start/end distance.
- Region-based streaming with a per-tick sampling budget.
- Memory cap for loaded regions.
- Designed as a lightweight foundation for PojavLauncher/Android.

The renderer uses `WorldRenderEvents.AFTER_ENTITIES`, where Fabric 1.21.1 exposes the world MatrixStack and VertexConsumerProvider. See the Fabric API documentation for `WorldRenderContext.matrixStack()` and `consumers()`.

## Build

Minecraft 1.21.1 uses Java 21.

    ./gradlew build

The jar is produced in `build/libs/`.

## PojavLauncher

1. Install a Fabric 1.21.1 instance.
2. Build the mod.
3. Put the generated jar in the instance `mods` folder.
4. Start the instance.

Press **V** to toggle VoxyLite.

## Performance

This is an actual LOD renderer, but it is not yet equivalent to the original Voxy's highly optimized GPU mesh architecture. The current implementation intentionally favors a simple Fabric-compatible path. For Android, keep `lodDistanceChunks` around 64–128 and `updateBudgetPerTick` around 1–2.

## Next production-stage work

- persistent binary region cache
- asynchronous worker queue
- mesh deduplication
- hierarchical LOD levels (LOD0/LOD1/LOD2/LOD3)
- occlusion and frustum culling
- GPU vertex/index buffers
- biome tinting and texture/material sampling
- seamless stitching between different LOD levels

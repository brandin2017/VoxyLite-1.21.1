# Compilar VoxyLite con GitHub Actions

1. Crea un repositorio nuevo en GitHub.
2. Sube el contenido de este ZIP al repositorio.
3. Comprueba que exista `.github/workflows/build.yml`.
4. Haz Commit changes.
5. Abre la pestaña **Actions**.
6. Entra en **Build VoxyLite**.
7. Espera a que el trabajo `build` termine correctamente.
8. Abre la ejecución terminada.
9. En la parte inferior aparecerá **Artifacts**.
10. Descarga `VoxyLite-1.21.1-Fabric`.
11. Dentro estará el `.jar` que puedes instalar en la carpeta `mods` de tu instancia Fabric 1.21.1.

El workflow configura Java 21, prepara Gradle, genera el Gradle Wrapper, ejecuta `./gradlew build` y conserva los JAR de `build/libs` como artifact.
